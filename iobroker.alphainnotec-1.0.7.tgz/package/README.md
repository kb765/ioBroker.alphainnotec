# ioBroker.alphainnotec

Simple ioBroker adapter to read values from a Luxtronik (alpha innotec) heat pump web frontend.

## Features

- Configurable Luxtronik IP and PIN
- Periodic polling of the web frontend
- Creates temperature states:
  - `temperatures.outdoor`
  - `temperatures.flow`
  - `temperatures.return`

## Configuration

Configure in adapter instance settings:

- `ip`: IP address of the Luxtronik web frontend
- `pin`: Access PIN
- `pollInterval`: polling interval in seconds (minimum 15)

## Build

```bash
npm run build
```

## Start

```bash
npm start
```

## Notes

Luxtronik firmware versions can expose different endpoints and field names. The adapter currently tries common endpoint patterns and extracts values from JSON or HTML-like responses.
